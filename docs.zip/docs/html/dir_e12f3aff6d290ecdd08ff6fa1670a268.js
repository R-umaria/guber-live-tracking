var dir_e12f3aff6d290ecdd08ff6fa1670a268 =
[
    [ ".NETCoreApp,Version=v8.0.AssemblyAttributes.cs", "_guber_demo_client_2obj_2_debug_2net8_80_2_8_n_e_t_core_app_00_version_0av8_80_8_assembly_attributes_8cs.html", null ],
    [ "GuberDemoClient.AssemblyInfo.cs", "_guber_demo_client_8_assembly_info_8cs.html", null ],
    [ "GuberDemoClient.GlobalUsings.g.cs", "_guber_demo_client_8_global_usings_8g_8cs.html", null ]
];