var _service_abstractions_8cs =
[
    [ "Guber.CoordinatesApi.Services.IGeocodingService", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_geocoding_service.html", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_geocoding_service" ],
    [ "Guber.CoordinatesApi.Services.IRoutingService", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_routing_service.html", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_routing_service" ],
    [ "Guber.CoordinatesApi.Services.IFareService", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_fare_service.html", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_fare_service" ],
    [ "Guber.CoordinatesApi.Services.ILocationStore", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_location_store.html", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_location_store" ]
];