var _geocoding_service_8cs =
[
    [ "Guber.CoordinatesApi.Services.NominatimGeocodingService", "class_guber_1_1_coordinates_api_1_1_services_1_1_nominatim_geocoding_service.html", "class_guber_1_1_coordinates_api_1_1_services_1_1_nominatim_geocoding_service" ]
];