var _live_api_tests_8cs =
[
    [ "CoordinatesApi.Tests.LiveApiTests", "class_coordinates_api_1_1_tests_1_1_live_api_tests.html", "class_coordinates_api_1_1_tests_1_1_live_api_tests" ]
];