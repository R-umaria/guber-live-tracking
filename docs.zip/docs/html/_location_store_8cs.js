var _location_store_8cs =
[
    [ "Guber.CoordinatesApi.Services.InMemoryLocationStore", "class_guber_1_1_coordinates_api_1_1_services_1_1_in_memory_location_store.html", "class_guber_1_1_coordinates_api_1_1_services_1_1_in_memory_location_store" ]
];