var _program_8cs =
[
    [ "AddControllers", "_program_8cs.html#abc3694a0e15618f2499e5a540264f833", null ],
    [ "AddCors", "_program_8cs.html#a062baa8af6464d3578eff276db4fa2d1", null ],
    [ "AddEndpointsApiExplorer", "_program_8cs.html#a0d7859f9cad50e8e9fdf015100780e07", null ],
    [ "AddHttpClient< Guber.CoordinatesApi.Services.IGeocodingService, Guber.CoordinatesApi.Services.NominatimGeocodingService >", "_program_8cs.html#aa38e6e25968a9a6c2ce3b62839906d07", null ],
    [ "AddHttpClient< Guber.CoordinatesApi.Services.IRoutingService, Guber.CoordinatesApi.Services.OsrmRoutingService >", "_program_8cs.html#ad47a5639fe4a8bf33d187647cf2ab72e", null ],
    [ "AddScoped< Guber.CoordinatesApi.Services.IEstimateService, Guber.CoordinatesApi.Services.EstimateService >", "_program_8cs.html#ac78fc9eba8e05193fdbdea7ff2a6955d", null ],
    [ "AddSingleton< Guber.CoordinatesApi.Services.IFareService, Guber.CoordinatesApi.Services.FareService >", "_program_8cs.html#a648dce7b43d04574b2ea766aaeb81981", null ],
    [ "AddSingleton< Guber.CoordinatesApi.Services.ILocationStore, Guber.CoordinatesApi.Services.InMemoryLocationStore >", "_program_8cs.html#abe2064421c67583b9bc418dbf2579107", null ],
    [ "AddSwaggerGen", "_program_8cs.html#ae0ce43c019a5621d731d0c622c793644", null ],
    [ "MapControllers", "_program_8cs.html#a9e2ee3170aa6279b68eefd1651f7d96c", null ],
    [ "Run", "_program_8cs.html#aaa3dbf02e269c3ef7e8546d290c6b3dd", null ],
    [ "UseCors", "_program_8cs.html#a67d35f7eca0f23b1c44c5ab37ca8db7b", null ],
    [ "UseHttpsRedirection", "_program_8cs.html#aa4d447fc3129a3aa301d736b8bd04ae9", null ],
    [ "UseSwagger", "_program_8cs.html#a9a5cfe7fee09f478241b98af703affea", null ],
    [ "UseSwaggerUI", "_program_8cs.html#a968f30949d31f6febdcf7f3fe40bfa42", null ],
    [ "app", "_program_8cs.html#a7b225fcb720e4d5ed2bbf60e28a25e6d", null ],
    [ "builder", "_program_8cs.html#a2f78352277081c620fd4cf92a5ce15e5", null ],
    [ "corsPolicy", "_program_8cs.html#a9026761770a93614dd7df7b8bd39d9a1", null ]
];