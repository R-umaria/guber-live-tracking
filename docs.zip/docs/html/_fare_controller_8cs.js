var _fare_controller_8cs =
[
    [ "Guber.CoordinatesApi.Controllers.FareController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_fare_controller.html", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_fare_controller" ]
];