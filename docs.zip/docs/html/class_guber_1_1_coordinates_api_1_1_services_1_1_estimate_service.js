var class_guber_1_1_coordinates_api_1_1_services_1_1_estimate_service =
[
    [ "EstimateService", "class_guber_1_1_coordinates_api_1_1_services_1_1_estimate_service.html#ac0e9f92ff860f7557b0713a92936c717", null ],
    [ "GetEstimateAsync", "class_guber_1_1_coordinates_api_1_1_services_1_1_estimate_service.html#a16b9352ebc5a212f9c8d8766baa1cfc8", null ]
];