var class_guber_1_1_coordinates_api_1_1_controllers_1_1_estimate_controller =
[
    [ "EstimateController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_estimate_controller.html#a0403c5e8b2c8e0858ca610fda3f73a3a", null ],
    [ "Estimate", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_estimate_controller.html#a06de8d8fff3a5abed02e1d088f8975f0", null ]
];