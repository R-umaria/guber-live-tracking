var files_dup =
[
    [ "Guber.CoordinatesApi", "dir_4f1ad45eb89e332a7aceffc95c29c8d8.html", "dir_4f1ad45eb89e332a7aceffc95c29c8d8" ],
    [ "GuberDemoClient", "dir_c406a87f82fbb9112046d15a7d9f155a.html", "dir_c406a87f82fbb9112046d15a7d9f155a" ],
    [ "Tests", "dir_33c78a012c8d08979f57a54a07694c46.html", "dir_33c78a012c8d08979f57a54a07694c46" ]
];