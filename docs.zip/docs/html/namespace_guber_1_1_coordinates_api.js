var namespace_guber_1_1_coordinates_api =
[
    [ "Controllers", "namespace_guber_1_1_coordinates_api_1_1_controllers.html", "namespace_guber_1_1_coordinates_api_1_1_controllers" ],
    [ "Models", "namespace_guber_1_1_coordinates_api_1_1_models.html", [
      [ "EstimateRequest", "namespace_guber_1_1_coordinates_api_1_1_models.html#a373d8383d699b36425e5ff1427191e84", null ],
      [ "EstimateResponse", "namespace_guber_1_1_coordinates_api_1_1_models.html#a29c46bc321f7a18764888b8acd2bcf2e", null ],
      [ "FareRequest", "namespace_guber_1_1_coordinates_api_1_1_models.html#a629a9f935efaed6851aa08ad1d61b79c", null ],
      [ "FareResponse", "namespace_guber_1_1_coordinates_api_1_1_models.html#a749bec9ef0d05b2248050ceb52b983f7", null ],
      [ "GeocodeResult", "namespace_guber_1_1_coordinates_api_1_1_models.html#a87cc27209abf928eb7158399d4769aaf", null ],
      [ "LastLocationResponse", "namespace_guber_1_1_coordinates_api_1_1_models.html#a7e75dcae12eb5d75a981e177a5e38e3b", null ],
      [ "LiveLocationUpdate", "namespace_guber_1_1_coordinates_api_1_1_models.html#a3dad1d195124851c6b137753700f09b1", null ],
      [ "RouteRequest", "namespace_guber_1_1_coordinates_api_1_1_models.html#a1857adb7d55a2a6ff25a5357f51d0a4b", null ],
      [ "RouteResponse", "namespace_guber_1_1_coordinates_api_1_1_models.html#ae640d449d327a90de571d0069ac416cc", null ]
    ] ],
    [ "Services", "namespace_guber_1_1_coordinates_api_1_1_services.html", "namespace_guber_1_1_coordinates_api_1_1_services" ],
    [ "WeatherForecast", "class_guber_1_1_coordinates_api_1_1_weather_forecast.html", "class_guber_1_1_coordinates_api_1_1_weather_forecast" ]
];