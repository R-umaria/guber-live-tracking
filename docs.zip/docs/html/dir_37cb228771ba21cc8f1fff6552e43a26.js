var dir_37cb228771ba21cc8f1fff6552e43a26 =
[
    [ "obj", "dir_d5e602a805b619dde99c4d0b5b6d458a.html", "dir_d5e602a805b619dde99c4d0b5b6d458a" ],
    [ "LiveApiTests.cs", "_live_api_tests_8cs.html", "_live_api_tests_8cs" ],
    [ "TestSettings.cs", "_test_settings_8cs.html", null ]
];