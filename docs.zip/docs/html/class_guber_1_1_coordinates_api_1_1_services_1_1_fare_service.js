var class_guber_1_1_coordinates_api_1_1_services_1_1_fare_service =
[
    [ "FareService", "class_guber_1_1_coordinates_api_1_1_services_1_1_fare_service.html#a6a789153e22443d9b2316d25734e8f4e", null ],
    [ "Calculate", "class_guber_1_1_coordinates_api_1_1_services_1_1_fare_service.html#aaa79f492f623c9ecdadb0ae2e5bda4c5", null ]
];