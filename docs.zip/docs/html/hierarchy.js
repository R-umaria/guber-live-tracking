var hierarchy =
[
    [ "ControllerBase", null, [
      [ "Guber.CoordinatesApi.Controllers.EstimateController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_estimate_controller.html", null ],
      [ "Guber.CoordinatesApi.Controllers.FareController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_fare_controller.html", null ],
      [ "Guber.CoordinatesApi.Controllers.GeocodingController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_geocoding_controller.html", null ],
      [ "Guber.CoordinatesApi.Controllers.HealthController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_health_controller.html", null ],
      [ "Guber.CoordinatesApi.Controllers.LiveLocationController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_live_location_controller.html", null ],
      [ "Guber.CoordinatesApi.Controllers.RoutingController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_routing_controller.html", null ],
      [ "Guber.CoordinatesApi.Controllers.WeatherForecastController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_weather_forecast_controller.html", null ]
    ] ],
    [ "DemoClient", "class_demo_client.html", null ],
    [ "DemoClient.EstimateResponse", "class_demo_client_1_1_estimate_response.html", null ],
    [ "DemoClient.FareResponse", "class_demo_client_1_1_fare_response.html", null ],
    [ "DemoClient.GeoResponse", "class_demo_client_1_1_geo_response.html", null ],
    [ "Guber.CoordinatesApi.Services.IEstimateService", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_estimate_service.html", [
      [ "Guber.CoordinatesApi.Services.EstimateService", "class_guber_1_1_coordinates_api_1_1_services_1_1_estimate_service.html", null ]
    ] ],
    [ "Guber.CoordinatesApi.Services.IFareService", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_fare_service.html", [
      [ "Guber.CoordinatesApi.Services.FareService", "class_guber_1_1_coordinates_api_1_1_services_1_1_fare_service.html", null ]
    ] ],
    [ "Guber.CoordinatesApi.Services.IGeocodingService", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_geocoding_service.html", [
      [ "Guber.CoordinatesApi.Services.NominatimGeocodingService", "class_guber_1_1_coordinates_api_1_1_services_1_1_nominatim_geocoding_service.html", null ]
    ] ],
    [ "Guber.CoordinatesApi.Services.ILocationStore", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_location_store.html", [
      [ "Guber.CoordinatesApi.Services.InMemoryLocationStore", "class_guber_1_1_coordinates_api_1_1_services_1_1_in_memory_location_store.html", null ]
    ] ],
    [ "Guber.CoordinatesApi.Services.IRoutingService", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_routing_service.html", [
      [ "Guber.CoordinatesApi.Services.OsrmRoutingService", "class_guber_1_1_coordinates_api_1_1_services_1_1_osrm_routing_service.html", null ]
    ] ],
    [ "CoordinatesApi.Tests.LiveApiTests", "class_coordinates_api_1_1_tests_1_1_live_api_tests.html", null ],
    [ "DemoClient.RoutePoint", "class_demo_client_1_1_route_point.html", null ],
    [ "DemoClient.RouteWire", "class_demo_client_1_1_route_wire.html", null ],
    [ "Guber.CoordinatesApi.WeatherForecast", "class_guber_1_1_coordinates_api_1_1_weather_forecast.html", null ]
];