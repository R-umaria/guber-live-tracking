var _health_controller_8cs =
[
    [ "Guber.CoordinatesApi.Controllers.HealthController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_health_controller.html", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_health_controller" ]
];