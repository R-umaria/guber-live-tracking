var class_demo_client_1_1_route_wire =
[
    [ "DistanceKm", "class_demo_client_1_1_route_wire.html#a7e3927269099ccd9f3843ef5605301e9", null ],
    [ "DurationMinutes", "class_demo_client_1_1_route_wire.html#adcaaf0c80524fdcaa1064bda1eceb736", null ],
    [ "Polyline", "class_demo_client_1_1_route_wire.html#ad889932ff78a168396d1bbf67c722bc8", null ]
];