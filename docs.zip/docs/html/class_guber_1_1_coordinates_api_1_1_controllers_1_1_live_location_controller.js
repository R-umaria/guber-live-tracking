var class_guber_1_1_coordinates_api_1_1_controllers_1_1_live_location_controller =
[
    [ "LiveLocationController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_live_location_controller.html#a3e7e3d4a090a8c1d4045c1b18d42c501", null ],
    [ "Last", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_live_location_controller.html#a765a17485eb9b3e90021c3e1ab6d003c", null ],
    [ "UpdateDriver", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_live_location_controller.html#ada2f1f81f112f816878dfc1c4e16dbc2", null ],
    [ "UpdateUser", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_live_location_controller.html#ab058461a474b776bcad4e2c9bfde2236", null ]
];