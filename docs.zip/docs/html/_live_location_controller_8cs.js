var _live_location_controller_8cs =
[
    [ "Guber.CoordinatesApi.Controllers.LiveLocationController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_live_location_controller.html", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_live_location_controller" ]
];