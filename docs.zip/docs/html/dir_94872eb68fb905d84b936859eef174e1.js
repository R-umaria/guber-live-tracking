var dir_94872eb68fb905d84b936859eef174e1 =
[
    [ ".NETCoreApp,Version=v8.0.AssemblyAttributes.cs", "_guber_8_coordinates_api_2obj_2_debug_2net8_80_2_8_n_e_t_core_app_00_version_0av8_80_8_assembly_attributes_8cs.html", null ],
    [ "Guber.CoordinatesApi.AssemblyInfo.cs", "_guber_8_coordinates_api_8_assembly_info_8cs.html", null ],
    [ "Guber.CoordinatesApi.GlobalUsings.g.cs", "_guber_8_coordinates_api_8_global_usings_8g_8cs.html", null ]
];