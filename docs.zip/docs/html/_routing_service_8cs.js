var _routing_service_8cs =
[
    [ "Guber.CoordinatesApi.Services.OsrmRoutingService", "class_guber_1_1_coordinates_api_1_1_services_1_1_osrm_routing_service.html", "class_guber_1_1_coordinates_api_1_1_services_1_1_osrm_routing_service" ]
];