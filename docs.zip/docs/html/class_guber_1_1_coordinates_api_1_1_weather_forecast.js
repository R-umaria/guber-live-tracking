var class_guber_1_1_coordinates_api_1_1_weather_forecast =
[
    [ "Date", "class_guber_1_1_coordinates_api_1_1_weather_forecast.html#aa194da4b719b2316fab84e0933a97593", null ],
    [ "Summary", "class_guber_1_1_coordinates_api_1_1_weather_forecast.html#a76997dc4a67089197319e954a8cfd6a3", null ],
    [ "TemperatureC", "class_guber_1_1_coordinates_api_1_1_weather_forecast.html#a32e6ea826dfee8c401afe7b8b0419003", null ],
    [ "TemperatureF", "class_guber_1_1_coordinates_api_1_1_weather_forecast.html#a540b677300c734896b0f28f1a22fffb6", null ]
];