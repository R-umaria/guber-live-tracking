var _common_dtos_8cs =
[
    [ "Guber.CoordinatesApi.Models.EstimateRequest", "namespace_guber_1_1_coordinates_api_1_1_models.html#a373d8383d699b36425e5ff1427191e84", null ],
    [ "Guber.CoordinatesApi.Models.EstimateResponse", "namespace_guber_1_1_coordinates_api_1_1_models.html#a29c46bc321f7a18764888b8acd2bcf2e", null ],
    [ "Guber.CoordinatesApi.Models.FareRequest", "namespace_guber_1_1_coordinates_api_1_1_models.html#a629a9f935efaed6851aa08ad1d61b79c", null ],
    [ "Guber.CoordinatesApi.Models.FareResponse", "namespace_guber_1_1_coordinates_api_1_1_models.html#a749bec9ef0d05b2248050ceb52b983f7", null ],
    [ "Guber.CoordinatesApi.Models.GeocodeResult", "namespace_guber_1_1_coordinates_api_1_1_models.html#a87cc27209abf928eb7158399d4769aaf", null ],
    [ "Guber.CoordinatesApi.Models.LastLocationResponse", "namespace_guber_1_1_coordinates_api_1_1_models.html#a7e75dcae12eb5d75a981e177a5e38e3b", null ],
    [ "Guber.CoordinatesApi.Models.LiveLocationUpdate", "namespace_guber_1_1_coordinates_api_1_1_models.html#a3dad1d195124851c6b137753700f09b1", null ],
    [ "Guber.CoordinatesApi.Models.RouteRequest", "namespace_guber_1_1_coordinates_api_1_1_models.html#a1857adb7d55a2a6ff25a5357f51d0a4b", null ],
    [ "Guber.CoordinatesApi.Models.RouteResponse", "namespace_guber_1_1_coordinates_api_1_1_models.html#ae640d449d327a90de571d0069ac416cc", null ]
];