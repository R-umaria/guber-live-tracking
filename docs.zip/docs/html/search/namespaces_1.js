var searchData=
[
  ['guber_0',['Guber',['../namespace_guber.html',1,'']]],
  ['guber_3a_3acoordinatesapi_1',['CoordinatesApi',['../namespace_guber_1_1_coordinates_api.html',1,'Guber']]],
  ['guber_3a_3acoordinatesapi_3a_3acontrollers_2',['Controllers',['../namespace_guber_1_1_coordinates_api_1_1_controllers.html',1,'Guber::CoordinatesApi']]],
  ['guber_3a_3acoordinatesapi_3a_3amodels_3',['Models',['../namespace_guber_1_1_coordinates_api_1_1_models.html',1,'Guber::CoordinatesApi']]],
  ['guber_3a_3acoordinatesapi_3a_3aservices_4',['Services',['../namespace_guber_1_1_coordinates_api_1_1_services.html',1,'Guber::CoordinatesApi']]]
];
