var searchData=
[
  ['calc_0',['Calc',['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_fare_controller.html#a2862d0235fd69f339a94374dc61fdcaa',1,'Guber::CoordinatesApi::Controllers::FareController']]],
  ['calculate_1',['Calculate',['../class_guber_1_1_coordinates_api_1_1_services_1_1_fare_service.html#aaa79f492f623c9ecdadb0ae2e5bda4c5',1,'Guber.CoordinatesApi.Services.FareService.Calculate()'],['../interface_guber_1_1_coordinates_api_1_1_services_1_1_i_fare_service.html#a38b8989986f5b14de03d8c547e1c0cca',1,'Guber.CoordinatesApi.Services.IFareService.Calculate()']]],
  ['calculation_20module_2',['🧭 Guber – Coordinates &amp;amp; Fare Calculation Module',['../md__r_e_a_d_m_e.html',1,'']]],
  ['changelog_2emd_3',['CHANGELOG.md',['../_c_h_a_n_g_e_l_o_g_8md.html',1,'']]],
  ['clone_20the_20repository_4',['2 Clone the repository',['../md__r_e_a_d_m_e.html#autotoc_md10',1,'']]],
  ['commondtos_2ecs_5',['CommonDtos.cs',['../_common_dtos_8cs.html',1,'']]],
  ['console_20output_6',['Console Output',['../md__regression_testing.html#autotoc_md19',1,'']]],
  ['contributors_7',['Contributors',['../md__r_e_a_d_m_e.html#autotoc_md15',1,'']]],
  ['coordinates_20fare_20api_8',['Regression Testing – Sprint 2 (Coordinates &amp;amp; Fare API)',['../md__regression_testing.html',1,'']]],
  ['coordinates_20fare_20calculation_20module_9',['🧭 Guber – Coordinates &amp;amp; Fare Calculation Module',['../md__r_e_a_d_m_e.html',1,'']]],
  ['coordinates_20fare_20module_20team_10',['Coordinates &amp;amp; Fare Module Team',['../md__r_e_a_d_m_e.html#autotoc_md16',1,'']]],
  ['coordinatesapi_11',['CoordinatesApi',['../namespace_coordinates_api.html',1,'']]],
  ['coordinatesapi_20–_20sprint_202_20release_20notes_12',['Guber.CoordinatesApi – Sprint 2 Release Notes',['../md__c_h_a_n_g_e_l_o_g.html',1,'']]],
  ['coordinatesapi_2etests_2eassemblyinfo_2ecs_13',['CoordinatesApi.Tests.AssemblyInfo.cs',['../_coordinates_api_8_tests_8_assembly_info_8cs.html',1,'']]],
  ['coordinatesapi_2etests_2eglobalusings_2eg_2ecs_14',['CoordinatesApi.Tests.GlobalUsings.g.cs',['../_coordinates_api_8_tests_8_global_usings_8g_8cs.html',1,'']]],
  ['coordinatesapi_3a_3atests_15',['Tests',['../namespace_coordinates_api_1_1_tests.html',1,'CoordinatesApi']]],
  ['corspolicy_16',['corsPolicy',['../_program_8cs.html#a9026761770a93614dd7df7b8bd39d9a1',1,'Program.cs']]]
];
