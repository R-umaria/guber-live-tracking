var searchData=
[
  ['2_20clone_20the_20repository_0',['2 Clone the repository',['../md__r_e_a_d_m_e.html#autotoc_md10',1,'']]],
  ['2_20coordinates_20fare_20api_1',['Regression Testing – Sprint 2 (Coordinates &amp;amp; Fare API)',['../md__regression_testing.html',1,'']]],
  ['2_20release_20notes_2',['Guber.CoordinatesApi – Sprint 2 Release Notes',['../md__c_h_a_n_g_e_l_o_g.html',1,'']]]
];
