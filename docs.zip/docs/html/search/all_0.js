var searchData=
[
  ['_2enetcoreapp_2cversion_3dv8_2e0_2eassemblyattributes_2ecs_0',['.NETCoreApp,Version=v8.0.AssemblyAttributes.cs',['../_guber_8_coordinates_api_2obj_2_debug_2net8_80_2_8_n_e_t_core_app_00_version_0av8_80_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../_guber_demo_client_2obj_2_debug_2net8_80_2_8_n_e_t_core_app_00_version_0av8_80_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../_tests_2_coordinates_api_8_tests_2obj_2_debug_2net8_80_2_8_n_e_t_core_app_00_version_0av8_80_8_assembly_attributes_8cs.html',1,'(Global Namespace)']]]
];
