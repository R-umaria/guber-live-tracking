var searchData=
[
  ['iestimateservice_0',['IEstimateService',['../interface_guber_1_1_coordinates_api_1_1_services_1_1_i_estimate_service.html',1,'Guber::CoordinatesApi::Services']]],
  ['ifareservice_1',['IFareService',['../interface_guber_1_1_coordinates_api_1_1_services_1_1_i_fare_service.html',1,'Guber::CoordinatesApi::Services']]],
  ['igeocodingservice_2',['IGeocodingService',['../interface_guber_1_1_coordinates_api_1_1_services_1_1_i_geocoding_service.html',1,'Guber::CoordinatesApi::Services']]],
  ['ilocationstore_3',['ILocationStore',['../interface_guber_1_1_coordinates_api_1_1_services_1_1_i_location_store.html',1,'Guber::CoordinatesApi::Services']]],
  ['improved_4',['Improved',['../md__c_h_a_n_g_e_l_o_g.html#autotoc_md3',1,'']]],
  ['inmemorylocationstore_5',['InMemoryLocationStore',['../class_guber_1_1_coordinates_api_1_1_services_1_1_in_memory_location_store.html',1,'Guber::CoordinatesApi::Services']]],
  ['iroutingservice_6',['IRoutingService',['../interface_guber_1_1_coordinates_api_1_1_services_1_1_i_routing_service.html',1,'Guber::CoordinatesApi::Services']]],
  ['issues_7',['Known Issues',['../md__c_h_a_n_g_e_l_o_g.html#autotoc_md4',1,'']]]
];
