var searchData=
[
  ['healthcontroller_0',['HealthController',['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_health_controller.html',1,'Guber::CoordinatesApi::Controllers']]]
];
