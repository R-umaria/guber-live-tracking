var searchData=
[
  ['coordinatesapi_0',['CoordinatesApi',['../namespace_coordinates_api.html',1,'']]],
  ['coordinatesapi_3a_3atests_1',['Tests',['../namespace_coordinates_api_1_1_tests.html',1,'CoordinatesApi']]]
];
