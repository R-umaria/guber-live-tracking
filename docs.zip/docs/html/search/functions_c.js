var searchData=
[
  ['weatherforecastcontroller_0',['WeatherForecastController',['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_weather_forecast_controller.html#a303d2da32b48ca27577a390719273ec8',1,'Guber::CoordinatesApi::Controllers::WeatherForecastController']]]
];
