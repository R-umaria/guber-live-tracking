var indexSectionsWithContent =
{
  0: ".123abcdefghiklmnoprstuw–🧭",
  1: "defghilnorw",
  2: "cg",
  3: ".cdefghlprstw",
  4: "acefghlmnoruw",
  5: "abc",
  6: "dflpst",
  7: "123acfgikmnoprst–🧭"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Properties",
  7: "Pages"
};

