var searchData=
[
  ['team_0',['Coordinates &amp;amp; Fare Module Team',['../md__r_e_a_d_m_e.html#autotoc_md16',1,'']]],
  ['temperaturec_1',['TemperatureC',['../class_guber_1_1_coordinates_api_1_1_weather_forecast.html#a32e6ea826dfee8c401afe7b8b0419003',1,'Guber::CoordinatesApi::WeatherForecast']]],
  ['temperaturef_2',['TemperatureF',['../class_guber_1_1_coordinates_api_1_1_weather_forecast.html#a540b677300c734896b0f28f1a22fffb6',1,'Guber::CoordinatesApi::WeatherForecast']]],
  ['test_20matrix_3',['Test Matrix',['../md__regression_testing.html#autotoc_md18',1,'']]],
  ['testing_20–_20sprint_202_20coordinates_20fare_20api_4',['Regression Testing – Sprint 2 (Coordinates &amp;amp; Fare API)',['../md__regression_testing.html',1,'']]],
  ['testsettings_2ecs_5',['TestSettings.cs',['../_test_settings_8cs.html',1,'']]],
  ['the_20api_6',['3 Run the api',['../md__r_e_a_d_m_e.html#autotoc_md11',1,'']]],
  ['the_20repository_7',['2 Clone the repository',['../md__r_e_a_d_m_e.html#autotoc_md10',1,'']]],
  ['totalfare_8',['TotalFare',['../class_demo_client_1_1_fare_response.html#ad0c721240b53731cfc01fc5339013be3',1,'DemoClient::FareResponse']]]
];
