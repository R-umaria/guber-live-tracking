var searchData=
[
  ['osrmroutingservice_0',['OsrmRoutingService',['../class_guber_1_1_coordinates_api_1_1_services_1_1_osrm_routing_service.html#a53a3fe5269a8d964d4088dbe6ab96e0c',1,'Guber::CoordinatesApi::Services::OsrmRoutingService']]]
];
