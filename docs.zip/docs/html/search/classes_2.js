var searchData=
[
  ['farecontroller_0',['FareController',['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_fare_controller.html',1,'Guber::CoordinatesApi::Controllers']]],
  ['fareresponse_1',['FareResponse',['../class_demo_client_1_1_fare_response.html',1,'DemoClient']]],
  ['fareservice_2',['FareService',['../class_guber_1_1_coordinates_api_1_1_services_1_1_fare_service.html',1,'Guber::CoordinatesApi::Services']]]
];
