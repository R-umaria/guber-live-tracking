var searchData=
[
  ['–_20coordinates_20fare_20calculation_20module_0',['🧭 Guber – Coordinates &amp;amp; Fare Calculation Module',['../md__r_e_a_d_m_e.html',1,'']]],
  ['–_20sprint_202_20coordinates_20fare_20api_1',['Regression Testing – Sprint 2 (Coordinates &amp;amp; Fare API)',['../md__regression_testing.html',1,'']]],
  ['–_20sprint_202_20release_20notes_2',['Guber.CoordinatesApi – Sprint 2 Release Notes',['../md__c_h_a_n_g_e_l_o_g.html',1,'']]]
];
