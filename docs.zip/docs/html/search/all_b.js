var searchData=
[
  ['health_5fshouldreturnok_0',['Health_ShouldReturnOk',['../class_coordinates_api_1_1_tests_1_1_live_api_tests.html#a37bee230645a4498d3524e9c279bfc29',1,'CoordinatesApi::Tests::LiveApiTests']]],
  ['healthcontroller_1',['HealthController',['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_health_controller.html',1,'Guber::CoordinatesApi::Controllers']]],
  ['healthcontroller_2ecs_2',['HealthController.cs',['../_health_controller_8cs.html',1,'']]]
];
