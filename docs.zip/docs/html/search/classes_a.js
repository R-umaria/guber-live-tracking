var searchData=
[
  ['weatherforecast_0',['WeatherForecast',['../class_guber_1_1_coordinates_api_1_1_weather_forecast.html',1,'Guber::CoordinatesApi']]],
  ['weatherforecastcontroller_1',['WeatherForecastController',['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_weather_forecast_controller.html',1,'Guber::CoordinatesApi::Controllers']]]
];
