var searchData=
[
  ['serviceabstractions_2ecs_0',['ServiceAbstractions.cs',['../_service_abstractions_8cs.html',1,'']]],
  ['sprint_202_20coordinates_20fare_20api_1',['Regression Testing – Sprint 2 (Coordinates &amp;amp; Fare API)',['../md__regression_testing.html',1,'']]],
  ['sprint_202_20release_20notes_2',['Guber.CoordinatesApi – Sprint 2 Release Notes',['../md__c_h_a_n_g_e_l_o_g.html',1,'']]],
  ['started_3',['Getting Started',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['summary_4',['Summary',['../class_guber_1_1_coordinates_api_1_1_weather_forecast.html#a76997dc4a67089197319e954a8cfd6a3',1,'Guber::CoordinatesApi::WeatherForecast']]]
];
