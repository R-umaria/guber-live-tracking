var searchData=
[
  ['sprint_202_20coordinates_20fare_20api_0',['Regression Testing – Sprint 2 (Coordinates &amp;amp; Fare API)',['../md__regression_testing.html',1,'']]],
  ['sprint_202_20release_20notes_1',['Guber.CoordinatesApi – Sprint 2 Release Notes',['../md__c_h_a_n_g_e_l_o_g.html',1,'']]],
  ['started_2',['Getting Started',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]]
];
