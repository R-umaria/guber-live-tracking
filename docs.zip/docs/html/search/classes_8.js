var searchData=
[
  ['osrmroutingservice_0',['OsrmRoutingService',['../class_guber_1_1_coordinates_api_1_1_services_1_1_osrm_routing_service.html',1,'Guber::CoordinatesApi::Services']]]
];
