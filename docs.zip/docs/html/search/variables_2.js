var searchData=
[
  ['corspolicy_0',['corsPolicy',['../_program_8cs.html#a9026761770a93614dd7df7b8bd39d9a1',1,'Program.cs']]]
];
