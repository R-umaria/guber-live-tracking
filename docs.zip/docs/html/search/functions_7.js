var searchData=
[
  ['main_0',['Main',['../class_demo_client.html#ac5bef47bd9027c45d5594ed1a3367b18',1,'DemoClient']]],
  ['mapcontrollers_1',['MapControllers',['../_program_8cs.html#a9e2ee3170aa6279b68eefd1651f7d96c',1,'Program.cs']]]
];
