var searchData=
[
  ['🧭_20guber_20–_20coordinates_20fare_20calculation_20module_0',['🧭 Guber – Coordinates &amp;amp; Fare Calculation Module',['../md__r_e_a_d_m_e.html',1,'']]]
];
