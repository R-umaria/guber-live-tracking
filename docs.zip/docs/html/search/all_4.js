var searchData=
[
  ['addcontrollers_0',['AddControllers',['../_program_8cs.html#abc3694a0e15618f2499e5a540264f833',1,'Program.cs']]],
  ['addcors_1',['AddCors',['../_program_8cs.html#a062baa8af6464d3578eff276db4fa2d1',1,'Program.cs']]],
  ['added_2',['Added',['../md__c_h_a_n_g_e_l_o_g.html#autotoc_md2',1,'']]],
  ['addendpointsapiexplorer_3',['AddEndpointsApiExplorer',['../_program_8cs.html#a0d7859f9cad50e8e9fdf015100780e07',1,'Program.cs']]],
  ['addhttpclient_3c_20guber_2ecoordinatesapi_2eservices_2eigeocodingservice_2c_20guber_2ecoordinatesapi_2eservices_2enominatimgeocodingservice_20_3e_4',['AddHttpClient&lt; Guber.CoordinatesApi.Services.IGeocodingService, Guber.CoordinatesApi.Services.NominatimGeocodingService &gt;',['../_program_8cs.html#aa38e6e25968a9a6c2ce3b62839906d07',1,'Program.cs']]],
  ['addhttpclient_3c_20guber_2ecoordinatesapi_2eservices_2eiroutingservice_2c_20guber_2ecoordinatesapi_2eservices_2eosrmroutingservice_20_3e_5',['AddHttpClient&lt; Guber.CoordinatesApi.Services.IRoutingService, Guber.CoordinatesApi.Services.OsrmRoutingService &gt;',['../_program_8cs.html#ad47a5639fe4a8bf33d187647cf2ab72e',1,'Program.cs']]],
  ['addscoped_3c_20guber_2ecoordinatesapi_2eservices_2eiestimateservice_2c_20guber_2ecoordinatesapi_2eservices_2eestimateservice_20_3e_6',['AddScoped&lt; Guber.CoordinatesApi.Services.IEstimateService, Guber.CoordinatesApi.Services.EstimateService &gt;',['../_program_8cs.html#ac78fc9eba8e05193fdbdea7ff2a6955d',1,'Program.cs']]],
  ['addsingleton_3c_20guber_2ecoordinatesapi_2eservices_2eifareservice_2c_20guber_2ecoordinatesapi_2eservices_2efareservice_20_3e_7',['AddSingleton&lt; Guber.CoordinatesApi.Services.IFareService, Guber.CoordinatesApi.Services.FareService &gt;',['../_program_8cs.html#a648dce7b43d04574b2ea766aaeb81981',1,'Program.cs']]],
  ['addsingleton_3c_20guber_2ecoordinatesapi_2eservices_2eilocationstore_2c_20guber_2ecoordinatesapi_2eservices_2einmemorylocationstore_20_3e_8',['AddSingleton&lt; Guber.CoordinatesApi.Services.ILocationStore, Guber.CoordinatesApi.Services.InMemoryLocationStore &gt;',['../_program_8cs.html#abe2064421c67583b9bc418dbf2579107',1,'Program.cs']]],
  ['addswaggergen_9',['AddSwaggerGen',['../_program_8cs.html#ae0ce43c019a5621d731d0c622c793644',1,'Program.cs']]],
  ['api_10',['Regression Testing – Sprint 2 (Coordinates &amp;amp; Fare API)',['../md__regression_testing.html',1,'']]],
  ['api_11',['3 Run the api',['../md__r_e_a_d_m_e.html#autotoc_md11',1,'']]],
  ['api_20overview_12',['API overview',['../md__r_e_a_d_m_e.html#autotoc_md12',1,'']]],
  ['app_13',['app',['../_program_8cs.html#a7b225fcb720e4d5ed2bbf60e28a25e6d',1,'Program.cs']]]
];
