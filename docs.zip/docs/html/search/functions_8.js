var searchData=
[
  ['nominatimgeocodingservice_0',['NominatimGeocodingService',['../class_guber_1_1_coordinates_api_1_1_services_1_1_nominatim_geocoding_service.html#a7a8ac9a872699f61b4801590366745f9',1,'Guber::CoordinatesApi::Services::NominatimGeocodingService']]]
];
