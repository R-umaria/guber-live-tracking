var searchData=
[
  ['route_5fshouldreturndistanceandduration_0',['Route_ShouldReturnDistanceAndDuration',['../class_coordinates_api_1_1_tests_1_1_live_api_tests.html#a0ae63be228d2206123dcd81b444d2168',1,'CoordinatesApi::Tests::LiveApiTests']]],
  ['routerequest_1',['RouteRequest',['../namespace_guber_1_1_coordinates_api_1_1_models.html#a1857adb7d55a2a6ff25a5357f51d0a4b',1,'Guber::CoordinatesApi::Models']]],
  ['routeresponse_2',['RouteResponse',['../namespace_guber_1_1_coordinates_api_1_1_models.html#ae640d449d327a90de571d0069ac416cc',1,'Guber::CoordinatesApi::Models']]],
  ['routingcontroller_3',['RoutingController',['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_routing_controller.html#ac612241ae3b72bc2bfdff16dfefb860a',1,'Guber::CoordinatesApi::Controllers::RoutingController']]],
  ['run_4',['Run',['../_program_8cs.html#aaa3dbf02e269c3ef7e8546d290c6b3dd',1,'Program.cs']]]
];
