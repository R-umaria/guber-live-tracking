var searchData=
[
  ['nominatimgeocodingservice_0',['NominatimGeocodingService',['../class_guber_1_1_coordinates_api_1_1_services_1_1_nominatim_geocoding_service.html',1,'Guber.CoordinatesApi.Services.NominatimGeocodingService'],['../class_guber_1_1_coordinates_api_1_1_services_1_1_nominatim_geocoding_service.html#a7a8ac9a872699f61b4801590366745f9',1,'Guber.CoordinatesApi.Services.NominatimGeocodingService.NominatimGeocodingService()']]],
  ['notes_1',['Notes',['../md__c_h_a_n_g_e_l_o_g.html',1,'Guber.CoordinatesApi – Sprint 2 Release Notes'],['../md__r_e_a_d_m_e.html#autotoc_md14',1,'Notes'],['../md__regression_testing.html#autotoc_md20',1,'Notes']]]
];
