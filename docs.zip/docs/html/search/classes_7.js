var searchData=
[
  ['nominatimgeocodingservice_0',['NominatimGeocodingService',['../class_guber_1_1_coordinates_api_1_1_services_1_1_nominatim_geocoding_service.html',1,'Guber::CoordinatesApi::Services']]]
];
