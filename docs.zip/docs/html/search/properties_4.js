var searchData=
[
  ['summary_0',['Summary',['../class_guber_1_1_coordinates_api_1_1_weather_forecast.html#a76997dc4a67089197319e954a8cfd6a3',1,'Guber::CoordinatesApi::WeatherForecast']]]
];
