var searchData=
[
  ['changelog_2emd_0',['CHANGELOG.md',['../_c_h_a_n_g_e_l_o_g_8md.html',1,'']]],
  ['commondtos_2ecs_1',['CommonDtos.cs',['../_common_dtos_8cs.html',1,'']]],
  ['coordinatesapi_2etests_2eassemblyinfo_2ecs_2',['CoordinatesApi.Tests.AssemblyInfo.cs',['../_coordinates_api_8_tests_8_assembly_info_8cs.html',1,'']]],
  ['coordinatesapi_2etests_2eglobalusings_2eg_2ecs_3',['CoordinatesApi.Tests.GlobalUsings.g.cs',['../_coordinates_api_8_tests_8_global_usings_8g_8cs.html',1,'']]]
];
