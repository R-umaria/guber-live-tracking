var searchData=
[
  ['matrix_0',['Test Matrix',['../md__regression_testing.html#autotoc_md18',1,'']]],
  ['module_1',['🧭 Guber – Coordinates &amp;amp; Fare Calculation Module',['../md__r_e_a_d_m_e.html',1,'']]],
  ['module_20team_2',['Coordinates &amp;amp; Fare Module Team',['../md__r_e_a_d_m_e.html#autotoc_md16',1,'']]]
];
