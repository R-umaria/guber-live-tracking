var searchData=
[
  ['calculation_20module_0',['🧭 Guber – Coordinates &amp;amp; Fare Calculation Module',['../md__r_e_a_d_m_e.html',1,'']]],
  ['clone_20the_20repository_1',['2 Clone the repository',['../md__r_e_a_d_m_e.html#autotoc_md10',1,'']]],
  ['console_20output_2',['Console Output',['../md__regression_testing.html#autotoc_md19',1,'']]],
  ['contributors_3',['Contributors',['../md__r_e_a_d_m_e.html#autotoc_md15',1,'']]],
  ['coordinates_20fare_20api_4',['Regression Testing – Sprint 2 (Coordinates &amp;amp; Fare API)',['../md__regression_testing.html',1,'']]],
  ['coordinates_20fare_20calculation_20module_5',['🧭 Guber – Coordinates &amp;amp; Fare Calculation Module',['../md__r_e_a_d_m_e.html',1,'']]],
  ['coordinates_20fare_20module_20team_6',['Coordinates &amp;amp; Fare Module Team',['../md__r_e_a_d_m_e.html#autotoc_md16',1,'']]],
  ['coordinatesapi_20–_20sprint_202_20release_20notes_7',['Guber.CoordinatesApi – Sprint 2 Release Notes',['../md__c_h_a_n_g_e_l_o_g.html',1,'']]]
];
