var searchData=
[
  ['serviceabstractions_2ecs_0',['ServiceAbstractions.cs',['../_service_abstractions_8cs.html',1,'']]]
];
