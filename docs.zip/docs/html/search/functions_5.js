var searchData=
[
  ['health_5fshouldreturnok_0',['Health_ShouldReturnOk',['../class_coordinates_api_1_1_tests_1_1_live_api_tests.html#a37bee230645a4498d3524e9c279bfc29',1,'CoordinatesApi::Tests::LiveApiTests']]]
];
