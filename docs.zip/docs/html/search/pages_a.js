var searchData=
[
  ['notes_0',['Notes',['../md__c_h_a_n_g_e_l_o_g.html',1,'Guber.CoordinatesApi – Sprint 2 Release Notes'],['../md__r_e_a_d_m_e.html#autotoc_md14',1,'Notes'],['../md__regression_testing.html#autotoc_md20',1,'Notes']]]
];
