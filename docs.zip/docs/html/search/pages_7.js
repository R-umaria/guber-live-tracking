var searchData=
[
  ['improved_0',['Improved',['../md__c_h_a_n_g_e_l_o_g.html#autotoc_md3',1,'']]],
  ['issues_1',['Known Issues',['../md__c_h_a_n_g_e_l_o_g.html#autotoc_md4',1,'']]]
];
