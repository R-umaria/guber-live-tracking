var searchData=
[
  ['fare_0',['Fare',['../class_demo_client_1_1_estimate_response.html#a55f16a1025355af2d6d34f8ce54163a2',1,'DemoClient::EstimateResponse']]]
];
