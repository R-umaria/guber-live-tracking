var searchData=
[
  ['liveapitests_0',['LiveApiTests',['../class_coordinates_api_1_1_tests_1_1_live_api_tests.html',1,'CoordinatesApi::Tests']]],
  ['livelocationcontroller_1',['LiveLocationController',['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_live_location_controller.html',1,'Guber::CoordinatesApi::Controllers']]]
];
