var searchData=
[
  ['osrmroutingservice_0',['OsrmRoutingService',['../class_guber_1_1_coordinates_api_1_1_services_1_1_osrm_routing_service.html',1,'Guber.CoordinatesApi.Services.OsrmRoutingService'],['../class_guber_1_1_coordinates_api_1_1_services_1_1_osrm_routing_service.html#a53a3fe5269a8d964d4088dbe6ab96e0c',1,'Guber.CoordinatesApi.Services.OsrmRoutingService.OsrmRoutingService()']]],
  ['output_1',['Console Output',['../md__regression_testing.html#autotoc_md19',1,'']]],
  ['overview_2',['API overview',['../md__r_e_a_d_m_e.html#autotoc_md12',1,'']]]
];
