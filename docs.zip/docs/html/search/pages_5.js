var searchData=
[
  ['fare_20api_0',['Regression Testing – Sprint 2 (Coordinates &amp;amp; Fare API)',['../md__regression_testing.html',1,'']]],
  ['fare_20calculation_20module_1',['🧭 Guber – Coordinates &amp;amp; Fare Calculation Module',['../md__r_e_a_d_m_e.html',1,'']]],
  ['fare_20formula_2',['Fare Formula',['../md__r_e_a_d_m_e.html#autotoc_md13',1,'']]],
  ['fare_20module_20team_3',['Coordinates &amp;amp; Fare Module Team',['../md__r_e_a_d_m_e.html#autotoc_md16',1,'']]],
  ['formula_4',['Fare Formula',['../md__r_e_a_d_m_e.html#autotoc_md13',1,'']]]
];
