var searchData=
[
  ['calc_0',['Calc',['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_fare_controller.html#a2862d0235fd69f339a94374dc61fdcaa',1,'Guber::CoordinatesApi::Controllers::FareController']]],
  ['calculate_1',['Calculate',['../class_guber_1_1_coordinates_api_1_1_services_1_1_fare_service.html#aaa79f492f623c9ecdadb0ae2e5bda4c5',1,'Guber.CoordinatesApi.Services.FareService.Calculate()'],['../interface_guber_1_1_coordinates_api_1_1_services_1_1_i_fare_service.html#a38b8989986f5b14de03d8c547e1c0cca',1,'Guber.CoordinatesApi.Services.IFareService.Calculate()']]]
];
