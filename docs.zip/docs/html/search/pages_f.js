var searchData=
[
  ['team_0',['Coordinates &amp;amp; Fare Module Team',['../md__r_e_a_d_m_e.html#autotoc_md16',1,'']]],
  ['test_20matrix_1',['Test Matrix',['../md__regression_testing.html#autotoc_md18',1,'']]],
  ['testing_20–_20sprint_202_20coordinates_20fare_20api_2',['Regression Testing – Sprint 2 (Coordinates &amp;amp; Fare API)',['../md__regression_testing.html',1,'']]],
  ['the_20api_3',['3 Run the api',['../md__r_e_a_d_m_e.html#autotoc_md11',1,'']]],
  ['the_20repository_4',['2 Clone the repository',['../md__r_e_a_d_m_e.html#autotoc_md10',1,'']]]
];
