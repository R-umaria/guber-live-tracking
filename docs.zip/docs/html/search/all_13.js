var searchData=
[
  ['readme_2emd_0',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['regression_20testing_20–_20sprint_202_20coordinates_20fare_20api_1',['Regression Testing – Sprint 2 (Coordinates &amp;amp; Fare API)',['../md__regression_testing.html',1,'']]],
  ['regressiontesting_2emd_2',['RegressionTesting.md',['../_regression_testing_8md.html',1,'']]],
  ['release_20notes_3',['Guber.CoordinatesApi – Sprint 2 Release Notes',['../md__c_h_a_n_g_e_l_o_g.html',1,'']]],
  ['repository_4',['2 Clone the repository',['../md__r_e_a_d_m_e.html#autotoc_md10',1,'']]],
  ['route_5fshouldreturndistanceandduration_5',['Route_ShouldReturnDistanceAndDuration',['../class_coordinates_api_1_1_tests_1_1_live_api_tests.html#a0ae63be228d2206123dcd81b444d2168',1,'CoordinatesApi::Tests::LiveApiTests']]],
  ['routepoint_6',['RoutePoint',['../class_demo_client_1_1_route_point.html',1,'DemoClient']]],
  ['routerequest_7',['RouteRequest',['../namespace_guber_1_1_coordinates_api_1_1_models.html#a1857adb7d55a2a6ff25a5357f51d0a4b',1,'Guber::CoordinatesApi::Models']]],
  ['routeresponse_8',['RouteResponse',['../namespace_guber_1_1_coordinates_api_1_1_models.html#ae640d449d327a90de571d0069ac416cc',1,'Guber::CoordinatesApi::Models']]],
  ['routewire_9',['RouteWire',['../class_demo_client_1_1_route_wire.html',1,'DemoClient']]],
  ['routingcontroller_10',['RoutingController',['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_routing_controller.html',1,'Guber.CoordinatesApi.Controllers.RoutingController'],['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_routing_controller.html#ac612241ae3b72bc2bfdff16dfefb860a',1,'Guber.CoordinatesApi.Controllers.RoutingController.RoutingController()']]],
  ['routingcontroller_2ecs_11',['RoutingController.cs',['../_routing_controller_8cs.html',1,'']]],
  ['routingservice_2ecs_12',['RoutingService.cs',['../_routing_service_8cs.html',1,'']]],
  ['run_13',['Run',['../_program_8cs.html#aaa3dbf02e269c3ef7e8546d290c6b3dd',1,'Program.cs']]],
  ['run_20the_20api_14',['3 Run the api',['../md__r_e_a_d_m_e.html#autotoc_md11',1,'']]]
];
