var searchData=
[
  ['geocodingcontroller_0',['GeocodingController',['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_geocoding_controller.html',1,'Guber::CoordinatesApi::Controllers']]],
  ['georesponse_1',['GeoResponse',['../class_demo_client_1_1_geo_response.html',1,'DemoClient']]]
];
