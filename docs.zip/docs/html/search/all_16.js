var searchData=
[
  ['updatedriver_0',['UpdateDriver',['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_live_location_controller.html#ada2f1f81f112f816878dfc1c4e16dbc2',1,'Guber::CoordinatesApi::Controllers::LiveLocationController']]],
  ['updateuser_1',['UpdateUser',['../class_guber_1_1_coordinates_api_1_1_controllers_1_1_live_location_controller.html#ab058461a474b776bcad4e2c9bfde2236',1,'Guber::CoordinatesApi::Controllers::LiveLocationController']]],
  ['upsert_2',['Upsert',['../class_guber_1_1_coordinates_api_1_1_services_1_1_in_memory_location_store.html#a0054491fed9ee14f84988de0e6d9f699',1,'Guber.CoordinatesApi.Services.InMemoryLocationStore.Upsert()'],['../interface_guber_1_1_coordinates_api_1_1_services_1_1_i_location_store.html#ae7aaa2caef086355bfc1d4ab4531e310',1,'Guber.CoordinatesApi.Services.ILocationStore.Upsert()']]],
  ['usecors_3',['UseCors',['../_program_8cs.html#a67d35f7eca0f23b1c44c5ab37ca8db7b',1,'Program.cs']]],
  ['usehttpsredirection_4',['UseHttpsRedirection',['../_program_8cs.html#aa4d447fc3129a3aa301d736b8bd04ae9',1,'Program.cs']]],
  ['useswagger_5',['UseSwagger',['../_program_8cs.html#a9a5cfe7fee09f478241b98af703affea',1,'Program.cs']]],
  ['useswaggerui_6',['UseSwaggerUI',['../_program_8cs.html#a968f30949d31f6febdcf7f3fe40bfa42',1,'Program.cs']]]
];
