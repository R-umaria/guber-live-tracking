var class_demo_client_1_1_geo_response =
[
    [ "DisplayName", "class_demo_client_1_1_geo_response.html#acdc093d13b961d14f1246902942cb00f", null ],
    [ "Latitude", "class_demo_client_1_1_geo_response.html#ab1817e5268cbf28baf82654041c32a15", null ],
    [ "Longitude", "class_demo_client_1_1_geo_response.html#a42876427bd6104eda9d16001aab67b6c", null ]
];