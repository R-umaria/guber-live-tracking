var class_guber_1_1_coordinates_api_1_1_controllers_1_1_fare_controller =
[
    [ "FareController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_fare_controller.html#a0bea985ab945b2895c6ce1b5ee70af7a", null ],
    [ "Calc", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_fare_controller.html#a2862d0235fd69f339a94374dc61fdcaa", null ]
];