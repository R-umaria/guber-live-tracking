var _weather_forecast_controller_8cs =
[
    [ "Guber.CoordinatesApi.Controllers.WeatherForecastController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_weather_forecast_controller.html", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_weather_forecast_controller" ]
];