var interface_guber_1_1_coordinates_api_1_1_services_1_1_i_fare_service =
[
    [ "Calculate", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_fare_service.html#a38b8989986f5b14de03d8c547e1c0cca", null ]
];