var interface_guber_1_1_coordinates_api_1_1_services_1_1_i_location_store =
[
    [ "Get", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_location_store.html#aa539026260acbfe3a8a6dcbc5b4deb80", null ],
    [ "Upsert", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_location_store.html#ae7aaa2caef086355bfc1d4ab4531e310", null ]
];