var class_guber_1_1_coordinates_api_1_1_services_1_1_nominatim_geocoding_service =
[
    [ "NominatimGeocodingService", "class_guber_1_1_coordinates_api_1_1_services_1_1_nominatim_geocoding_service.html#a7a8ac9a872699f61b4801590366745f9", null ],
    [ "GeocodeAsync", "class_guber_1_1_coordinates_api_1_1_services_1_1_nominatim_geocoding_service.html#abc069d5a0e82fdeefa98ed5cd5e85fa5", null ]
];