var _fare_service_8cs =
[
    [ "Guber.CoordinatesApi.Services.FareService", "class_guber_1_1_coordinates_api_1_1_services_1_1_fare_service.html", "class_guber_1_1_coordinates_api_1_1_services_1_1_fare_service" ]
];