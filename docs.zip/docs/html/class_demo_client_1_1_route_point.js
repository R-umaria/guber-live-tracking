var class_demo_client_1_1_route_point =
[
    [ "Lat", "class_demo_client_1_1_route_point.html#ac022c2ed5f146425df2604738b150fa3", null ],
    [ "Lon", "class_demo_client_1_1_route_point.html#a3b424723e33460dd9b1ad9019af82e9c", null ]
];