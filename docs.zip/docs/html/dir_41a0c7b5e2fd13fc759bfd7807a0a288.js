var dir_41a0c7b5e2fd13fc759bfd7807a0a288 =
[
    [ ".NETCoreApp,Version=v8.0.AssemblyAttributes.cs", "_tests_2_coordinates_api_8_tests_2obj_2_debug_2net8_80_2_8_n_e_t_core_app_00_version_0av8_80_8_assembly_attributes_8cs.html", null ],
    [ "CoordinatesApi.Tests.AssemblyInfo.cs", "_coordinates_api_8_tests_8_assembly_info_8cs.html", null ],
    [ "CoordinatesApi.Tests.GlobalUsings.g.cs", "_coordinates_api_8_tests_8_global_usings_8g_8cs.html", null ]
];