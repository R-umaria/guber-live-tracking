var class_demo_client_1_1_estimate_response =
[
    [ "DistanceKm", "class_demo_client_1_1_estimate_response.html#a1cf7469cb4ca0e8a28238425f8e5d85f", null ],
    [ "DurationMinutes", "class_demo_client_1_1_estimate_response.html#a4f11144066e4c74f76ddc5429769427a", null ],
    [ "Fare", "class_demo_client_1_1_estimate_response.html#a55f16a1025355af2d6d34f8ce54163a2", null ]
];