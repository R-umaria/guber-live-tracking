var interface_guber_1_1_coordinates_api_1_1_services_1_1_i_routing_service =
[
    [ "GetRouteAsync", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_routing_service.html#a6fca3f99541a4b19fe76079a2d8af306", null ]
];