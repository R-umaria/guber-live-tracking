var dir_33c78a012c8d08979f57a54a07694c46 =
[
    [ "CoordinatesApi.Tests", "dir_37cb228771ba21cc8f1fff6552e43a26.html", "dir_37cb228771ba21cc8f1fff6552e43a26" ]
];