var _estimate_service_8cs =
[
    [ "Guber.CoordinatesApi.Services.IEstimateService", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_estimate_service.html", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_estimate_service" ],
    [ "Guber.CoordinatesApi.Services.EstimateService", "class_guber_1_1_coordinates_api_1_1_services_1_1_estimate_service.html", "class_guber_1_1_coordinates_api_1_1_services_1_1_estimate_service" ]
];