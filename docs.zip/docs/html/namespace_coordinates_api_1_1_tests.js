var namespace_coordinates_api_1_1_tests =
[
    [ "LiveApiTests", "class_coordinates_api_1_1_tests_1_1_live_api_tests.html", "class_coordinates_api_1_1_tests_1_1_live_api_tests" ]
];