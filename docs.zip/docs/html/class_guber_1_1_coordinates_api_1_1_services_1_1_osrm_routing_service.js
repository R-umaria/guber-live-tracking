var class_guber_1_1_coordinates_api_1_1_services_1_1_osrm_routing_service =
[
    [ "OsrmRoutingService", "class_guber_1_1_coordinates_api_1_1_services_1_1_osrm_routing_service.html#a53a3fe5269a8d964d4088dbe6ab96e0c", null ],
    [ "GetRouteAsync", "class_guber_1_1_coordinates_api_1_1_services_1_1_osrm_routing_service.html#a37f19149bc3a9a0c793d7962810285d9", null ]
];