var annotated_dup =
[
    [ "CoordinatesApi", "namespace_coordinates_api.html", [
      [ "Tests", "namespace_coordinates_api_1_1_tests.html", [
        [ "LiveApiTests", "class_coordinates_api_1_1_tests_1_1_live_api_tests.html", "class_coordinates_api_1_1_tests_1_1_live_api_tests" ]
      ] ]
    ] ],
    [ "Guber", "namespace_guber.html", [
      [ "CoordinatesApi", "namespace_guber_1_1_coordinates_api.html", [
        [ "Controllers", "namespace_guber_1_1_coordinates_api_1_1_controllers.html", [
          [ "EstimateController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_estimate_controller.html", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_estimate_controller" ],
          [ "FareController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_fare_controller.html", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_fare_controller" ],
          [ "GeocodingController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_geocoding_controller.html", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_geocoding_controller" ],
          [ "HealthController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_health_controller.html", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_health_controller" ],
          [ "LiveLocationController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_live_location_controller.html", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_live_location_controller" ],
          [ "RoutingController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_routing_controller.html", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_routing_controller" ],
          [ "WeatherForecastController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_weather_forecast_controller.html", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_weather_forecast_controller" ]
        ] ],
        [ "Services", "namespace_guber_1_1_coordinates_api_1_1_services.html", [
          [ "EstimateService", "class_guber_1_1_coordinates_api_1_1_services_1_1_estimate_service.html", "class_guber_1_1_coordinates_api_1_1_services_1_1_estimate_service" ],
          [ "FareService", "class_guber_1_1_coordinates_api_1_1_services_1_1_fare_service.html", "class_guber_1_1_coordinates_api_1_1_services_1_1_fare_service" ],
          [ "IEstimateService", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_estimate_service.html", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_estimate_service" ],
          [ "IFareService", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_fare_service.html", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_fare_service" ],
          [ "IGeocodingService", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_geocoding_service.html", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_geocoding_service" ],
          [ "ILocationStore", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_location_store.html", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_location_store" ],
          [ "InMemoryLocationStore", "class_guber_1_1_coordinates_api_1_1_services_1_1_in_memory_location_store.html", "class_guber_1_1_coordinates_api_1_1_services_1_1_in_memory_location_store" ],
          [ "IRoutingService", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_routing_service.html", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_routing_service" ],
          [ "NominatimGeocodingService", "class_guber_1_1_coordinates_api_1_1_services_1_1_nominatim_geocoding_service.html", "class_guber_1_1_coordinates_api_1_1_services_1_1_nominatim_geocoding_service" ],
          [ "OsrmRoutingService", "class_guber_1_1_coordinates_api_1_1_services_1_1_osrm_routing_service.html", "class_guber_1_1_coordinates_api_1_1_services_1_1_osrm_routing_service" ]
        ] ],
        [ "WeatherForecast", "class_guber_1_1_coordinates_api_1_1_weather_forecast.html", "class_guber_1_1_coordinates_api_1_1_weather_forecast" ]
      ] ]
    ] ],
    [ "DemoClient", "class_demo_client.html", "class_demo_client" ]
];