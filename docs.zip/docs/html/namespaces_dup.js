var namespaces_dup =
[
    [ "CoordinatesApi", "namespace_coordinates_api.html", "namespace_coordinates_api" ],
    [ "Guber", "namespace_guber.html", "namespace_guber" ]
];