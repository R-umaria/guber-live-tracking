var interface_guber_1_1_coordinates_api_1_1_services_1_1_i_estimate_service =
[
    [ "GetEstimateAsync", "interface_guber_1_1_coordinates_api_1_1_services_1_1_i_estimate_service.html#a31960aac440da95e8ba494025e1ebf5e", null ]
];