var class_coordinates_api_1_1_tests_1_1_live_api_tests =
[
    [ "Estimate_ShouldReturnAll", "class_coordinates_api_1_1_tests_1_1_live_api_tests.html#a36ceb0425328b143e4079beaed61c171", null ],
    [ "Fare_ShouldReturnValidAmount", "class_coordinates_api_1_1_tests_1_1_live_api_tests.html#a2bde5092c4677732317b13c4010ff4be", null ],
    [ "Geocode_ShouldReturnLatLon", "class_coordinates_api_1_1_tests_1_1_live_api_tests.html#ad280f03307c71329f78e01688d2d196d", null ],
    [ "Health_ShouldReturnOk", "class_coordinates_api_1_1_tests_1_1_live_api_tests.html#a37bee230645a4498d3524e9c279bfc29", null ],
    [ "Route_ShouldReturnDistanceAndDuration", "class_coordinates_api_1_1_tests_1_1_live_api_tests.html#a0ae63be228d2206123dcd81b444d2168", null ]
];