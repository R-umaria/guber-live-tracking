var class_guber_1_1_coordinates_api_1_1_controllers_1_1_weather_forecast_controller =
[
    [ "WeatherForecastController", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_weather_forecast_controller.html#a303d2da32b48ca27577a390719273ec8", null ],
    [ "Get", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_weather_forecast_controller.html#a5092d30deaa6ef10ada7c72d9f46f63a", null ]
];