var _weather_forecast_8cs =
[
    [ "Guber.CoordinatesApi.WeatherForecast", "class_guber_1_1_coordinates_api_1_1_weather_forecast.html", "class_guber_1_1_coordinates_api_1_1_weather_forecast" ]
];