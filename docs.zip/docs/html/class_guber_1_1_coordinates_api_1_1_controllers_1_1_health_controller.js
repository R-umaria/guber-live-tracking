var class_guber_1_1_coordinates_api_1_1_controllers_1_1_health_controller =
[
    [ "Get", "class_guber_1_1_coordinates_api_1_1_controllers_1_1_health_controller.html#a2596a6b14bfa1e4a97671be5cbd31c36", null ]
];