var class_demo_client_1_1_fare_response =
[
    [ "TotalFare", "class_demo_client_1_1_fare_response.html#ad0c721240b53731cfc01fc5339013be3", null ]
];